# RTL AUTOMATION — EXECUTION CONTRACT (V4)

---

## OVERVIEW

System consists of:

Planner → Executor → Analyzer  
Agent orchestrates execution.

---

## DATA FLOW

Planner → run_plan.json  
Executor → status.json (per testcase)  
Analyzer → summary.xls  

Final Output:
output/<project>/summary/summary.xls

---

# ==============================
# STATUS DOMAINS
# ==============================

Planner Status:
- READY
- SKIPPED

Executor Status:
- PASSED
- FAILED
- NOT_EXECUTED
- NOT_PLANNED
- DISABLED

These MUST NOT be mixed.

---

# ==============================
# CASE SENSITIVITY
# ==============================

Planner:
- Case-sensitive (Excel mapping)

Executor (filters):
- Case-insensitive

Agent:
- Must normalize inputs

---

# ==============================
# PLANNER CONTRACT
# ==============================

## INPUT

- MASTER.xls
- Vector_Excel/*
- config.ini

---

## OUTPUT

output/<project>/plans/run_plan.json

---

## RESPONSIBILITY

- Validate inputs
- Map MASTER → SIM → COMMON
- Build configuration
- Decide execution eligibility

---

## TESTCASE STRUCTURE

{
  "Category": "...",
  "Item_Description": "...",
  "dir_name": "...",
  "sim_status": "READY | SKIPPED",
  "skip_reason": "...",
  "execute": true | false,
  "config": {...},
  "paths": {
    "testcase_dir": "output/<project>/<Category>/<dir_name>"
  }
}

---

## RULES

- MASTER is source of truth
- Planner MUST NOT execute anything
- Planner assigns only READY or SKIPPED

---

## STOP CONDITIONS

- MASTER missing
- workspace invalid
- SIM missing
- default_prj_name mismatch

---

# ==============================
# EXECUTOR CONTRACT
# ==============================

## INPUT

- run_plan.json
- executor_config.json

---

## RESPONSIBILITY

For each testcase:

1. CLEAN
2. COPY
3. PREPARE
4. EXECUTE
5. MONITOR
6. VALIDATE
7. SAVE status.json

---

## CLEAN RULE

- testcase_dir is deleted before execution
- ensures deterministic runs

---

## FILTER SUPPORT

{
  "filters": {
    "category": "IO"
  }
}

Rules:

- Case-insensitive
- If no match → fallback to ALL testcases

---

## ENV HANDLING

- env.scr is always regenerated from config
- If env.scr is a symlink → unlink first
- Permissions must be applied after generation
- In-place editing is NOT supported

---

## VALIDATION RULES

FAIL:
- ANY fail pattern present → FAILED

SUCCESS:
- ALL success patterns must exist → PASSED

Priority:
FAIL > SUCCESS

---

## EXECUTION RULES

- Stop execution on first FAILED stage
- run.scr must exist
- env.scr always regenerated
- No silent failures

---

## STATUS STRUCTURE

{
  "testcase": "...",
  "category": "...",
  "status": "PASSED | FAILED | NOT_EXECUTED | NOT_PLANNED",
  "start_time": "...",
  "end_time": "...",
  "duration_sec": ...,
  "stages": {
    "<stage>": {
      "status": "...",
      "error_message": "...",
      "validation": {...}
    }
  },
  "error_message": "..."
}

---

# ==============================
# ANALYZER CONTRACT
# ==============================

## INPUT

output/<project>/**/status.json

---

## OUTPUT

output/<project>/summary/summary.xls

---

## RESPONSIBILITY

- Read all status.json files
- Flatten nested stage structure
- Aggregate summary
- Generate Excel report

---

## NORMALIZATION

Input:

stages.<stage>.status  
stages.<stage>.error_message  

Convert to:

<stage>_status  
<stage>_error  

---

## SUMMARY FORMAT

category | total | PASSED | FAILED | NOT_EXECUTED | NOT_PLANNED  

Includes:

- OVERALL row
- Category rows

---

## RULES

- Analyzer is READ-ONLY
- Uses only status.json
- No inference
- Dynamic stage handling

---

# ==============================
# AGENT CONTRACT
# ==============================

## ROLE

Orchestrates:

- planner
- executor
- analyzer

---

## RESPONSIBILITY

- Interpret user intent
- Trigger correct skill(s)
- Pass filters to executor
- Maintain sequence

---

## COMMANDS

run planner → Planner  
run executor → Executor  
run analyzer → Analyzer  
run full flow → Planner → Executor → Analyzer  
run <category> → Executor with filter  

---

## EXECUTION RULES

- Full flow must follow strict order
- Do NOT skip steps
- Filtering only via executor

---

## FAILURE HANDLING

- Planner failure → STOP
- Executor failure → continue to analyzer
- Analyzer always runs

---

# ==============================
# GLOBAL RULES
# ==============================

- Planner reads Excel
- Executor reads JSON
- Analyzer reads status.json
- Agent does not process data

---

# ==============================
# DO NOT
# ==============================

- Do not auto-correct inputs
- Do not infer missing data
- Do not hide failures
- Do not mix responsibilities