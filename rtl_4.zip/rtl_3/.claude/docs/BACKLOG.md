# RTL AUTOMATION — BACKLOG

---

## PRIORITY 1 (NEXT RELEASE)

### 1. Step-Based Executor (Multi-Script per Stage)
- Support "steps" inside stage
- Allow multiple script execution
- Types:
  - copy
  - run
  - update
  - monitor
  - validate
- Backward compatible with current config

---

### 2. Rerun Failed Testcases
- Read status.json
- Filter FAILED testcases
- Re-execute only failed ones
- Agent command:
  run failed

---

### 3. Category Parallel Execution
- Run categories in parallel
- Keep testcases sequential inside category
- Configurable max_workers

---

## PRIORITY 2

### 4. Testcase-Level Parallel Execution
- Full parallelism
- Requires:
  - resource control
  - logging isolation

---

### 5. Advanced Filtering
- category + testcase
- status-based filtering
- combinations

Example:
run IO failed

---

### 6. Retry Mechanism
- Retry failed stage N times
- Configurable per stage

---

## PRIORITY 3

### 7. Validation Enhancements
- Ordered success patterns
- Regex support
- Multiple log files

---

### 8. Analyzer Enhancements
- Pass percentage
- Failure breakdown
- Stage-wise failure stats

---

### 9. Excel Formatting
- Color coding (PASS/FAIL)
- Highlight failures
- Better readability

---

## PRIORITY 4 (LONG TERM)

### 10. Dashboard UI
- Visual execution status
- Trends
- Failure tracking

---

### 11. Smart Agent
- Context-aware execution
- Suggest retries
- Suggest root cause

---

## NOTES

- Maintain backward compatibility
- Avoid breaking config formats
- Executor must remain deterministic