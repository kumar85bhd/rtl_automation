# EXECUTOR SKILL

---

## PURPOSE

Execute testcases defined in run_plan.json.

Executor performs full execution lifecycle:

CLEAN → COPY → PREPARE → RUN → MONITOR → VALIDATE → SAVE

---

## INPUT

- run_plan.json
- executor_config.json
  Executor behavior is driven by executor_config.json.
  All stage configuration MUST be read from this file.
  Do NOT hardcode behavior.
---

## CONFIG-DRIVEN EXECUTION

Executor behavior is driven by executor_config.json.

- All stage definitions (enable/run flags, copy rules, execution, monitor, validation) MUST be read from executor_config.json.
- Do NOT hardcode any stage behavior.
- Executor MUST interpret executor_config.json at runtime.

---
## ENV HANDLING

- env.scr is always regenerated from config (source of truth).
- If env.scr is a symlink, it MUST be unlinked before regeneration.
- Permissions MUST be set after regeneration (as defined in executor_config.json).
- In-place editing of env.scr is NOT supported in V4.
---
## OUTPUT

Per testcase:

output/<project>/<Category>/<dir_name>/status.json

---

## RESPONSIBILITY

For each testcase:

1. Clean previous data
2. Copy required files
3. Generate env.scr
4. Prepare run.scr
5. Execute scripts
6. Monitor execution
7. Validate logs
8. Save status.json

---

## FILTER SUPPORT

Executor supports optional filters:

{
  "filters": {
    "category": "IO"
  }
}

---

## FILTER RULES

- Matching is case-insensitive
- If filter matches testcases → execute subset
- If no match → fallback to ALL testcases (with warning)

---

## EXECUTION FLOW

Per testcase:

1. Delete testcase_dir
2. Recreate directory
3. Execute stages in order
4. Stop on first FAILED stage
5. Record status

---

## STAGE EXECUTION

Each stage performs:

- Copy files/folders
- Prepare scripts
- Run run.scr
- Wait for log file
- Validate log

---

## VALIDATION RULES

FAIL:
- Any fail pattern found → FAILED

SUCCESS:
- All success patterns must be present → PASSED

Priority:
FAIL > SUCCESS

---

## STATUS VALUES

- PASSED
- FAILED
- NOT_EXECUTED
- NOT_PLANNED
- DISABLED

---

## STATUS STRUCTURE

status.json includes:

- testcase
- category
- overall status
- start_time
- end_time
- duration_sec
- stages
- error_message

---

## EXECUTION RULES

- Stop execution on first failure
- run.scr must exist
- env.scr always regenerated
- No silent failures

---

## MONITORING

- Wait for log file generation
- Ensure file size stabilizes

---

## ERROR HANDLING

- Copy failure → FAIL stage
- Missing script → FAIL stage
- Execution failure → FAIL stage
- Validation failure → FAIL stage

---

## OUTPUT

- status.json per testcase
- Console logs for progress

---

## DO NOT

- Do not read Excel files
- Do not modify run_plan.json
- Do not skip validation
- Do not continue after stage failure

---

## FUTURE EXTENSIONS

- Rerun failed testcases
- Parallel execution
- Retry mechanism
- Advanced filtering