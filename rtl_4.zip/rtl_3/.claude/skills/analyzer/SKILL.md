# ANALYZER SKILL

---

## PURPOSE

Aggregate execution results from all `status.json` files and generate a structured Excel report.

Analyzer performs reporting only.  
No execution, planning, or validation is performed.

---

## DATA FLOW

Planner → run_plan.json  
Executor → status.json (per testcase)  
Analyzer → summary.xls  

---

## INPUT

Source:

output/<project>/summary/summary.xls

Project must be determined from:

output/<project_name>/plans/run_plan.json

---

## PROJECT RESOLUTION

Steps:

1. Locate run_plan.json under output/
2. Read:
   default_prj_name
3. Use:

output/<default_prj_name>/

Analyzer MUST NOT guess project folder.

---

## PROCESS FLOW

1. Discover all status.json files
2. Load each file
3. Normalize (flatten structure)
4. Aggregate:
   - Overall summary
   - Category-wise summary
5. Generate Excel report (.xls)

---

## NORMALIZATION

status.json contains nested stage structure:

stages.<stage>.status  
stages.<stage>.error_message  

Analyzer MUST flatten this into:

- <stage>_status
- <stage>_error

Example:

stages.sim.status → sim_status  
stages.sim.error_message → sim_error  

No flat fields (like sim_status) exist in source JSON.