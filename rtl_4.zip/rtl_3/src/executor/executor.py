import os
import json
import shutil
import time
import subprocess
from datetime import datetime


# -----------------------------
# LOAD CONFIGS
# -----------------------------

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)


def get_base_dir():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))


def load_configs():
    base = get_base_dir()

    output_dir = os.path.join(base, "output")
    projects = os.listdir(output_dir)

    if not projects:
        raise Exception("No project found in output/")

    project = projects[0]

    plan_path = os.path.join(output_dir, project, "plans", "run_plan.json")
    exec_cfg_path = os.path.join(base, "config", "executor_config.json")

    return load_json(plan_path), load_json(exec_cfg_path)


# -----------------------------
# UTILITIES
# -----------------------------

def clean_and_create_dir(path):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path, exist_ok=True)


def resolve_path(base, path):
    return os.path.join(base, path.lstrip("/"))


def copy_item(src, dest):
    print(f"[COPY] {src} → {dest}")

    if not os.path.exists(src):
        print(f"[ERROR] Missing source: {src}")
        return False

    os.makedirs(dest, exist_ok=True)

    if os.path.isfile(src):
        shutil.copy2(src, os.path.join(dest, os.path.basename(src)))
        return True

    # copy folder WITH ROOT
    dst_folder = os.path.join(dest, os.path.basename(src))
    shutil.copytree(src, dst_folder, dirs_exist_ok=True)
    return True


def wait_for_file(file_path, timeout=300):
    print(f"[MONITOR] Waiting for {file_path}")

    last_size = -1
    waited = 0

    while waited < timeout:
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)

            if size == last_size:
                print(f"[MONITOR] File stable: {file_path}")
                return True

            last_size = size

        time.sleep(2)
        waited += 2

    print(f"[ERROR] Timeout waiting for {file_path}")
    return False


# -----------------------------
# FILTERING
# -----------------------------

def filter_testcases(testcases, filters):
    """
    Filter testcases based on criteria.

    Supported:
    - category (case-insensitive)

    Returns:
        filtered list
    """

    if not filters:
        return testcases

    result = []

    for tc in testcases:

        if "category" in filters:
            if tc["Category"].lower() != filters["category"].lower():
                continue

        result.append(tc)

    return result


# -----------------------------
# VALIDATION
# -----------------------------

def validate_log(file_path, validation_cfg):
    """
    FAIL → OR logic
    SUCCESS → AND logic
    """

    details = {
        "file": file_path,
        "fail_patterns": validation_cfg.get("fail_patterns", []),
        "success_patterns": validation_cfg.get("success_patterns", []),
        "checked_lines": 0,
        "matched": {
            "type": None,
            "pattern": None,
            "line_number": None,
            "line": None
        },
        "missing_success_patterns": []
    }

    if not os.path.exists(file_path):
        return "FAILED", "Log file not found", details

    with open(file_path, "r", errors="ignore") as f:
        lines = f.readlines()

    details["checked_lines"] = len(lines)

    fail_patterns = [p.lower() for p in validation_cfg.get("fail_patterns", [])]
    success_patterns = [p.lower() for p in validation_cfg.get("success_patterns", [])]

    # FAIL (OR)
    for i, line in enumerate(lines):
        lower = line.lower()

        for pat in fail_patterns:
            if pat in lower:
                details["matched"] = {
                    "type": "FAIL",
                    "pattern": pat,
                    "line_number": i + 1,
                    "line": line.strip()
                }
                return "FAILED", f"{file_path}:{i+1}:{line.strip()}", details

    # SUCCESS (AND)
    found_patterns = set()

    for i, line in enumerate(lines):
        lower = line.lower()

        for pat in success_patterns:
            if pat in lower:
                found_patterns.add(pat)
                details["matched"] = {
                    "type": "SUCCESS",
                    "pattern": pat,
                    "line_number": i + 1,
                    "line": line.strip()
                }

    if success_patterns:
        missing = list(set(success_patterns) - found_patterns)
        details["missing_success_patterns"] = missing

        if not missing:
            return "PASSED", "", details
        else:
            return "FAILED", f"Missing success patterns: {missing}", details

    return "FAILED", "No success patterns defined", details


# -----------------------------
# SCRIPT HANDLING
# -----------------------------

def prepare_env_script(stage_dir, cfg, script_cfg):
    env_path = os.path.join(stage_dir, script_cfg["env_script"]["name"])

    if os.path.islink(env_path):
        os.unlink(env_path)

    with open(env_path, "w") as f:
        f.write(f"setenv DESIGN_PATH {cfg.get('design_path','')}\n")
        f.write(f"setenv RTL_PATH {cfg.get('dsim_path','')}\n")
        f.write(f"setenv WAVE_FILE {cfg.get('wave_tcl','')}\n")
        f.write(f"setenv SIM_MODE {cfg.get('define_sim_mode','')}\n")

    os.chmod(env_path, int(script_cfg["env_script"]["permissions"], 8))


def prepare_run_script(stage_dir, script_cfg):
    run_path = os.path.join(stage_dir, script_cfg["run_script"]["name"])

    if not os.path.exists(run_path):
        raise Exception(f"run.scr missing in {stage_dir}")

    os.chmod(run_path, int(script_cfg["run_script"]["permissions"], 8))


# -----------------------------
# EXECUTE STAGE
# -----------------------------

def execute_stage(stage_name, stage_cfg, testcase, exec_cfg, workspace):
    stage_dir = os.path.join(testcase["paths"]["testcase_dir"], stage_name)

    clean_and_create_dir(stage_dir)

    # COPY
    for rule in stage_cfg.get("copy_rules", []):
        src = resolve_path(workspace, rule["source_path"])
        dest = os.path.join(stage_dir, rule.get("dest_path", ""))

        if not copy_item(src, dest):
            return "FAILED", f"Copy failed: {src}", {}

    # PREPARE
    prepare_env_script(stage_dir, testcase["config"], exec_cfg["script_handling"])
    prepare_run_script(stage_dir, exec_cfg["script_handling"])

    # EXECUTE
    script = stage_cfg["execution"]["script"]
    script_path = os.path.join(stage_dir, script)

    if not os.path.exists(script_path):
        return "FAILED", f"{script} not found", {}

    print(f"[EXEC] {stage_name} → {script}")

    result = subprocess.run(
        ["csh", script],
        cwd=stage_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        return "FAILED", result.stderr, {}

    # MONITOR
    log_file = os.path.join(stage_dir, stage_cfg["monitor"]["file"])

    if not wait_for_file(log_file):
        return "FAILED", f"{log_file} not generated", {}

    return validate_log(log_file, stage_cfg["validation"])


# -----------------------------
# MAIN EXECUTOR
# -----------------------------

def run_executor():
    plan, exec_cfg = load_configs()

    workspace = plan["workspace_path"]

    # 🔥 FILTER SUPPORT
    filters = exec_cfg.get("filters", {})
    testcases = filter_testcases(plan["testcases"], filters)

    if not testcases:
        print("[WARN] No testcases matched filters → running ALL testcases")
        testcases = plan["testcases"]

    print(f"[INFO] Running {len(testcases)} testcases")

    for tc in testcases:

        testcase_start = datetime.now()
        testcase_dir = tc["paths"]["testcase_dir"]

        clean_and_create_dir(testcase_dir)

        result = {
            "testcase": tc["Item_Description"],
            "category": tc["Category"],
            "status": "NOT_EXECUTED",
            "start_time": testcase_start.isoformat(),
            "end_time": None,
            "duration_sec": 0,
            "stages": {},
            "error_message": ""
        }

        if not tc.get("execute", False):
            result["status"] = "NOT_PLANNED"

            for stage_name in exec_cfg["stages"]:
                result["stages"][stage_name] = {
                    "status": "NOT_PLANNED",
                    "error_message": "",
                    "validation": {}
                }

        else:
            result["status"] = "PASSED"

            for stage_name, stage_cfg in exec_cfg["stages"].items():

                stage_result = {
                    "status": "",
                    "error_message": "",
                    "validation": {}
                }

                if not stage_cfg.get("enabled", False):
                    stage_result["status"] = "DISABLED"

                elif not stage_cfg.get("run", False):
                    stage_result["status"] = "NOT_EXECUTED"

                else:
                    status, error, validation = execute_stage(
                        stage_name,
                        stage_cfg,
                        tc,
                        exec_cfg,
                        workspace
                    )

                    stage_result["status"] = status
                    stage_result["error_message"] = error
                    stage_result["validation"] = validation

                    if status == "FAILED":
                        result["status"] = "FAILED"
                        result["error_message"] = error

                result["stages"][stage_name] = stage_result

                if result["status"] == "FAILED":
                    break

        testcase_end = datetime.now()

        result["end_time"] = testcase_end.isoformat()
        result["duration_sec"] = (testcase_end - testcase_start).total_seconds()

        status_path = os.path.join(testcase_dir, "status.json")

        with open(status_path, "w") as f:
            json.dump(result, f, indent=2)

        print(f"[RESULT] {result['testcase']} → {result['status']}")

    print("\nExecution complete.\n")


# -----------------------------
# ENTRY
# -----------------------------

if __name__ == "__main__":
    run_executor()