import os
import json
from collections import defaultdict
import xlwt


# ============================================================
# BASE PATH
# ============================================================

def get_base_dir():
    """
    Returns project root directory.
    """
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))


# ============================================================
# PROJECT RESOLUTION
# ============================================================

def get_project_from_plan(base_dir):
    """
    Resolve project using run_plan.json (source of truth).
    """

    output_dir = os.path.join(base_dir, "output")

    for root, _, files in os.walk(output_dir):
        if "run_plan.json" in files:
            with open(os.path.join(root, "run_plan.json")) as f:
                plan = json.load(f)

            project = plan["default_prj_name"]
            project_dir = os.path.join(output_dir, project)

            if not os.path.exists(project_dir):
                raise Exception(f"Project folder missing: {project_dir}")

            return project_dir, project

    raise Exception("run_plan.json not found")


# ============================================================
# STATUS FILE COLLECTION
# ============================================================

def collect_status_files(project_dir):
    files = []

    for root, _, f in os.walk(project_dir):
        if "status.json" in f:
            files.append(os.path.join(root, "status.json"))

    return files


# ============================================================
# LOAD
# ============================================================

def load_status(file_path):
    with open(file_path) as f:
        return json.load(f)


# ============================================================
# FLATTEN
# ============================================================

def flatten(data):
    """
    Convert nested status.json → flat row
    """

    row = {
        "category": data.get("category"),
        "testcase": data.get("testcase"),
        "status": data.get("status"),
        "duration_sec": data.get("duration_sec"),
        "start_time": data.get("start_time"),
        "end_time": data.get("end_time"),
    }

    # Add dynamic stage info
    for stage, val in data.get("stages", {}).items():
        row[f"{stage}_status"] = val.get("status", "")
        row[f"{stage}_error"] = val.get("error_message", "")

    return row


# ============================================================
# AGGREGATION (CATEGORY + OVERALL)
# ============================================================

def aggregate_by_category(rows):
    categories = {}

    for r in rows:
        cat = r.get("category", "UNKNOWN")

        if cat not in categories:
            categories[cat] = {
                "category": cat,
                "total": 0,
                "PASSED": 0,
                "FAILED": 0,
                "NOT_EXECUTED": 0,
                "NOT_PLANNED": 0
            }

        categories[cat]["total"] += 1

        status = r.get("status", "")
        if status in categories[cat]:
            categories[cat][status] += 1

    return list(categories.values())


def aggregate_overall(rows):
    summary = {
        "category": "OVERALL",
        "total": len(rows),
        "PASSED": 0,
        "FAILED": 0,
        "NOT_EXECUTED": 0,
        "NOT_PLANNED": 0
    }

    for r in rows:
        status = r.get("status", "")
        if status in summary:
            summary[status] += 1

    return summary


# ============================================================
# XLS WRITER
# ============================================================

def write_xls(rows, output_path):
    wb = xlwt.Workbook()

    # --------------------------------------------------------
    # SUMMARY SHEET
    # --------------------------------------------------------
    ws = wb.add_sheet("Summary")

    headers = ["category", "total", "PASSED", "FAILED", "NOT_EXECUTED", "NOT_PLANNED"]

    # header
    for col, h in enumerate(headers):
        ws.write(0, col, h)

    category_summary = aggregate_by_category(rows)
    overall_summary = aggregate_overall(rows)

    row_idx = 1

    # overall row
    ws.write(row_idx, 0, overall_summary["category"])
    for col, h in enumerate(headers[1:], start=1):
        ws.write(row_idx, col, overall_summary[h])

    row_idx += 1

    # category rows
    for entry in category_summary:
        ws.write(row_idx, 0, entry["category"])

        for col, h in enumerate(headers[1:], start=1):
            ws.write(row_idx, col, entry[h])

        row_idx += 1

    # --------------------------------------------------------
    # CATEGORY SHEETS
    # --------------------------------------------------------
    category_map = defaultdict(list)

    for r in rows:
        category_map[r["category"]].append(r)

    for category, records in category_map.items():

        sheet_name = category[:31] if category else "UNKNOWN"
        ws = wb.add_sheet(sheet_name)

        # collect keys
        keys = set()
        for r in records:
            keys.update(r.keys())

        # ordered base columns
        base_cols = [
            "category",
            "testcase",
            "status",
            "duration_sec",
            "start_time",
            "end_time"
        ]

        stage_status_cols = sorted([k for k in keys if k.endswith("_status")])
        stage_error_cols = sorted([k for k in keys if k.endswith("_error")])

        columns = base_cols + stage_status_cols + stage_error_cols

        # header
        for col_idx, col in enumerate(columns):
            ws.write(0, col_idx, col)

        # rows
        for row_idx, r in enumerate(records, start=1):
            for col_idx, col in enumerate(columns):
                ws.write(row_idx, col_idx, r.get(col, ""))

    wb.save(output_path)


# ============================================================
# MAIN
# ============================================================

def run_analyzer():

    base = get_base_dir()

    project_dir, project = get_project_from_plan(base)

    print(f"[INFO] Project: {project}")

    status_files = collect_status_files(project_dir)

    if not status_files:
        print("[WARN] No status.json found")
        return

    rows = []
    for f in status_files:
        rows.append(flatten(load_status(f)))

    output_dir = os.path.join(project_dir, "summary")
    os.makedirs(output_dir, exist_ok=True)

    xls_path = os.path.join(output_dir, "summary.xls")

    write_xls(rows, xls_path)

    print(f"[OUTPUT] {xls_path}")


# ============================================================
# ENTRY
# ============================================================

if __name__ == "__main__":
    run_analyzer()