import os
import json
import configparser
from datetime import datetime
import xlrd


# -----------------------------
# CONSTANTS
# -----------------------------

SKIP_REASONS = {
    "VECTOR_FILE_MISSING": "Vector file missing",
    "NO_SIM_MAPPING": "No SIM mapping",
    "DIR_NAME_MISSING": "dir_name missing",
    "DUPLICATE_DIR_NAME": "Duplicate dir_name",
    "COMMON_MISSING": "COMMON sheet missing"
}


class PlannerStop(Exception):
    pass


# -----------------------------
# CONFIG
# -----------------------------

def load_config():
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
    config_path = os.path.join(base_dir, "config", "config.ini")

    if not os.path.exists(config_path):
        raise PlannerStop(f"Config file missing: {config_path}")

    parser = configparser.ConfigParser()
    parser.read(config_path)

    if "PATHS" not in parser:
        raise PlannerStop("Missing [PATHS] section")

    cfg = parser["PATHS"]

    workspace = cfg.get("workspace_path")
    master = cfg.get("master_file_path")
    vector = cfg.get("vector_excel_path")

    if not all([workspace, master, vector]):
        raise PlannerStop("Config missing required fields")

    return workspace, master, vector


def validate_workspace(path):
    if not os.path.exists(path):
        raise PlannerStop("workspace_path invalid: does not exist")

    if not os.path.isdir(path):
        raise PlannerStop("workspace_path invalid: not a directory")

    if not os.access(path, os.R_OK):
        raise PlannerStop("workspace_path invalid: not readable")


# -----------------------------
# EXCEL HELPERS
# -----------------------------

def open_workbook(path):
    if not os.path.exists(path):
        raise PlannerStop(f"File not found: {path}")
    return xlrd.open_workbook(path)


def get_sheet(wb, name):
    for s in wb.sheet_names():
        if s.lower() == name.lower():
            return wb.sheet_by_name(s)
    return None


def read_master(path):
    wb = open_workbook(path)
    sheet = wb.sheet_by_index(0)

    headers = [str(sheet.cell_value(0, c)).strip() for c in range(sheet.ncols)]

    if "Category" not in headers or "Item_Description" not in headers:
        raise PlannerStop("MASTER missing required columns")

    cat_idx = headers.index("Category")
    item_idx = headers.index("Item_Description")

    data = []

    for r in range(1, sheet.nrows):
        cat = str(sheet.cell_value(r, cat_idx)).strip()
        item = str(sheet.cell_value(r, item_idx)).strip()

        if cat and item:
            data.append({
                "Category": cat,
                "Item_Description": item
            })

    if not data:
        raise PlannerStop("MASTER empty")

    return data


def read_common(sheet):
    data = {}

    for r in range(1, sheet.nrows):
        key = str(sheet.cell_value(r, 0)).strip()
        val = str(sheet.cell_value(r, 1)).strip()

        if key:
            data[key] = val

    return data


def read_table(sheet):
    headers = [str(sheet.cell_value(0, c)).strip() for c in range(sheet.ncols)]

    if "Item_Description" not in headers:
        return []

    idx_map = {h: i for i, h in enumerate(headers)}

    rows = []

    for r in range(1, sheet.nrows):
        row = {}

        for h, i in idx_map.items():
            row[h] = str(sheet.cell_value(r, i)).strip()

        if row.get("Item_Description"):
            rows.append(row)

    return rows


def load_vector_file(path):
    if not os.path.exists(path):
        return None

    wb = xlrd.open_workbook(path)

    return {
        "common": get_sheet(wb, "common"),
        "sim": get_sheet(wb, "sim"),
        "vector": get_sheet(wb, "vector"),
        "back": get_sheet(wb, "back_annotation")
    }


# -----------------------------
# MAIN PLANNER
# -----------------------------

def build_plan():
    workspace, master_path, vector_path = load_config()

    validate_workspace(workspace)

    master = read_master(master_path)
    categories = sorted(set(r["Category"] for r in master))

    vector_data = {}
    default_prj_name = None

    # -----------------------------
    # LOAD VECTOR FILES
    # -----------------------------
    for cat in categories:
        file_path = os.path.join(vector_path, f"vector_{cat}.xls")

        vf = load_vector_file(file_path)

        if vf is None:
            vector_data[cat] = None
            continue

        common_sheet = vf["common"]

        if common_sheet is None:
            vector_data[cat] = {"error": SKIP_REASONS["COMMON_MISSING"]}
            continue

        common = read_common(common_sheet)

        if "default_prj_name" not in common:
            raise PlannerStop("default_prj_name missing")

        if default_prj_name is None:
            default_prj_name = common["default_prj_name"]
        elif default_prj_name != common["default_prj_name"]:
            raise PlannerStop("default_prj_name mismatch")

        # SIM
        sim_sheet = vf["sim"]
        if sim_sheet is None:
            raise PlannerStop("SIM missing")

        sim_rows = read_table(sim_sheet)
        if not sim_rows:
            raise PlannerStop("SIM empty")

        sim_lookup = {}
        for r in sim_rows:
            key = r["Item_Description"]
            if key not in sim_lookup:
                sim_lookup[key] = r

        # OPTIONAL
        vector_lookup = {}
        back_lookup = {}

        if vf["vector"]:
            for r in read_table(vf["vector"]):
                vector_lookup[r["Item_Description"]] = r

        if vf["back"]:
            for r in read_table(vf["back"]):
                back_lookup[r["Item_Description"]] = r

        vector_data[cat] = {
            "common": common,
            "sim": sim_lookup,
            "vector": vector_lookup,
            "back": back_lookup
        }

    # -----------------------------
    # PROCESS TESTCASES
    # -----------------------------
    used_dir = set()
    testcases = []
    skipped = []

    for row in master:
        cat = row["Category"]
        item = row["Item_Description"]

        entry = {
            "Category": cat,
            "Item_Description": item,
            "dir_name": "",
            "sim_status": "",
            "skip_reason": "",
            "execute": False,
            "paths": {},
            "config": {},
            "stages": {}
        }

        vdata = vector_data.get(cat)

        if vdata is None:
            entry["sim_status"] = "SKIPPED"
            entry["skip_reason"] = SKIP_REASONS["VECTOR_FILE_MISSING"]

        elif "error" in vdata:
            entry["sim_status"] = "SKIPPED"
            entry["skip_reason"] = vdata["error"]

        else:
            sim_lookup = vdata["sim"]

            if item not in sim_lookup:
                entry["sim_status"] = "SKIPPED"
                entry["skip_reason"] = SKIP_REASONS["NO_SIM_MAPPING"]

            else:
                sim_row = sim_lookup[item]
                dir_name = str(sim_row.get("dir_name", "")).strip()

                if not dir_name:
                    entry["sim_status"] = "SKIPPED"
                    entry["skip_reason"] = SKIP_REASONS["DIR_NAME_MISSING"]

                elif dir_name in used_dir:
                    entry["sim_status"] = "SKIPPED"
                    entry["skip_reason"] = SKIP_REASONS["DUPLICATE_DIR_NAME"]

                else:
                    entry["sim_status"] = "READY"
                    entry["dir_name"] = dir_name
                    entry["execute"] = True
                    used_dir.add(dir_name)

                    # PATHS (UPDATED)
                    entry["paths"] = {
                        "testcase_dir": f"output/{default_prj_name}/{cat}/{dir_name}",
                        "sim_dir": f"output/{default_prj_name}/{cat}/{dir_name}/sim",
                        "sim_wave_dir": f"output/{default_prj_name}/{cat}/{dir_name}/sim_wave",
                        "vector_dir": f"output/{default_prj_name}/{cat}/{dir_name}/vector",
                        "back_annotation_dir": f"output/{default_prj_name}/{cat}/{dir_name}/back_annotation",
                        "back_annotation_wave_dir": f"output/{default_prj_name}/{cat}/{dir_name}/back_annotation_wave"
                    }

                    # CONFIG
                    cfg = dict(vdata["common"])
                    for k, v in sim_row.items():
                        if k not in ["Item_Description", "dir_name", "Category"]:
                            cfg[k] = v

                    # FIX PATH SWAP (CRITICAL)
                    if "dsim_path" in cfg and "default_rtl_path" in cfg:
                        dsim = cfg["dsim_path"]
                        rtl = cfg["default_rtl_path"]

                        # swap if wrong
                        if "DESIGN" in dsim and "DSIM" in rtl:
                            cfg["dsim_path"], cfg["default_rtl_path"] = rtl, dsim

                    entry["config"] = cfg

                    # STAGES
                    entry["stages"] = {
                        "sim": sim_row,
                        "vector": vdata["vector"].get(item, {}),
                        "back_annotation": vdata["back"].get(item, {})
                    }

        if entry["sim_status"] == "SKIPPED":
            skipped.append({
                "Item_Description": item,
                "reason": entry["skip_reason"]
            })

        testcases.append(entry)

    summary = {
        "total": len(testcases),
        "ready": sum(1 for t in testcases if t["sim_status"] == "READY"),
        "skipped": sum(1 for t in testcases if t["sim_status"] == "SKIPPED"),
        "skipped_reasons": skipped
    }

    return {
        "default_prj_name": default_prj_name,
        "workspace_path": workspace,
        "plan_created": datetime.now().isoformat(),
        "summary": summary,
        "testcases": testcases
    }


# -----------------------------
# WRITE OUTPUT
# -----------------------------

def write_plan(plan):
    project = plan["default_prj_name"]
    out_dir = os.path.join("output", project, "plans")

    os.makedirs(out_dir, exist_ok=True)

    path = os.path.join(out_dir, "run_plan.json")

    with open(path, "w") as f:
        json.dump(plan, f, indent=2)

    print(f"\nPlan written: {path}\n")


# -----------------------------
# ENTRY
# -----------------------------

def main():
    try:
        plan = build_plan()
        write_plan(plan)

        print(json.dumps(plan["summary"], indent=2))

    except PlannerStop as e:
        print(f"\n[STOP] {e}\n")


if __name__ == "__main__":
    main()