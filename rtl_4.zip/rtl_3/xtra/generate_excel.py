import os
import xlwt

BASE_DIR = os.getcwd()

# -----------------------------
# CONFIG (single source of truth)
# -----------------------------
categories = {
    "IO": ["TST_IO", "TST_VOL", "TST_VOH"],
    "MEM": ["TST_MEM_RD", "TST_MEM_WR", "TST_MEM_STRESS"]
}

# -----------------------------
# CREATE MASTER.xls
# -----------------------------
wb = xlwt.Workbook()
sheet = wb.add_sheet("MASTER")

headers = ["Category", "Item_Description"]

for col, h in enumerate(headers):
    sheet.write(0, col, h)

row_idx = 1
for category, items in categories.items():
    for item in items:
        sheet.write(row_idx, 0, category)
        sheet.write(row_idx, 1, item)
        row_idx += 1

wb.save("MASTER.xls")


# -----------------------------
# COMMON DATA (shared)
# -----------------------------
common_data = [
    ["key", "value"],
    ["design_path", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace/DESIGN"],
    ["default_rtl_path", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace/DSIM"],
    ["ref_vector_dir", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace/vector"],
    ["dir_path", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace"],
    ["default_sim_rom", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace/DSIM/FW_BIN/EVT0/2P5SP_EVT0_RISCV.bin"],
    ["default_sim_header", "/mnt/c/Users/Administrator/Downloads/rtl_3/Workspace/DSIM/common/FW_BIN/EVT0/2P5SP_EVT0_RISCV.HW.RegsMap.h"],
    ["default_prj_name", "S5K2P5SP_EVT0"],
    ["default_ver_id", "V000"],
    ["default_date_stamp", "26010900"],
    ["cycle", "41.66"]
]

# -----------------------------
# CREATE Vector_Excel folder
# -----------------------------
os.makedirs("Vector_Excel", exist_ok=True)


# -----------------------------
# GENERATE EXCEL PER CATEGORY
# -----------------------------
for category, items in categories.items():

    wb = xlwt.Workbook()

    # ---- COMMON ----
    sheet = wb.add_sheet("common")
    for r, row in enumerate(common_data):
        for c, val in enumerate(row):
            sheet.write(r, c, val)

    # ---- SIM ----
    sheet = wb.add_sheet("sim")

    sim_headers = ["dir_name", "Item_Description", "sim_setfile", "wave_tcl", "define_sim_mode"]

    for c, h in enumerate(sim_headers):
        sheet.write(0, c, h)

    for idx, item in enumerate(items):
        row = [
            f"{idx:04d}_{item}",
            item,
            "",
            "wave.do",
            f"{category}_MODE"
        ]
        for c, val in enumerate(row):
            sheet.write(idx + 1, c, val)

    # ---- VECTOR ----
    sheet = wb.add_sheet("vector")

    vector_headers = ["dir_name", "Item_Description", "define_sim_mode"]

    for c, h in enumerate(vector_headers):
        sheet.write(0, c, h)

    for idx, item in enumerate(items):
        row = [
            f"{idx:04d}_{item}",
            item,
            "LOADMEM"
        ]
        for c, val in enumerate(row):
            sheet.write(idx + 1, c, val)

    # Save per category
    wb.save(f"Vector_Excel/vector_{category}.xls")


print("\n✅ Excel files generated successfully for IO and MEM!\n")