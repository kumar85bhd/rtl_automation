# RTL AUTOMATION — EXECUTION CONTRACT (V4)

---

## OVERVIEW

System consists of four components:

Planner → Executor → Analyzer  
Agent orchestrates execution.

---

## DATA FLOW

Planner → run_plan.json  
Executor → status.json (per testcase)  
Analyzer → summary.xls  

Agent triggers flow only and does not modify data.

---

# ==============================
# PLANNER CONTRACT
# ==============================

## INPUT

- MASTER.xls  
- Vector_Excel/*  
- config.ini  

---

## OUTPUT

output/<project_name>/plans/run_plan.json

---

## RESPONSIBILITY

- Validate inputs  
- Map MASTER → SIM → COMMON  
- Build testcase config  
- Decide execution eligibility  

---

## TESTCASE STRUCTURE

{
  "Category": "...",
  "Item_Description": "...",
  "dir_name": "...",
  "sim_status": "READY | SKIPPED",
  "skip_reason": "...",
  "execute": true | false,
  "config": {...},
  "paths": {
    "testcase_dir": "output/<project>/<Category>/<dir_name>"
  }
}

---

## RULES

- MASTER is source of truth  
- Planner does NOT execute anything  
- Planner assigns ONLY:
  - READY  
  - SKIPPED  

---

## STOP CONDITIONS

- MASTER missing  
- workspace invalid  
- SIM missing  
- default_prj_name mismatch  

---

# ==============================
# EXECUTOR CONTRACT
# ==============================

## INPUT

- run_plan.json  
- executor_config.json  

---

## OUTPUT

output/<project>/<Category>/<dir_name>/status.json  

---

## RESPONSIBILITY

Per testcase:

1. CLEAN  
2. COPY  
3. PREPARE  
4. EXECUTE  
5. MONITOR  
6. VALIDATE  
7. SAVE status.json  

---

## CLEAN RULE

- testcase_dir is deleted before execution  
- Ensures deterministic runs  

---

## FILTER SUPPORT

{
  "filters": {
    "category": "IO"
  }
}

Rules:

- Case-insensitive matching  
- If no match → fallback to ALL testcases  

---

## VALIDATION RULES

- FAIL → ANY fail pattern (OR)  
- SUCCESS → ALL success patterns (AND)  
- FAIL has priority  

---

## STATUS STRUCTURE

{
  "testcase": "...",
  "category": "...",
  "status": "PASSED | FAILED | NOT_EXECUTED | NOT_PLANNED",
  "start_time": "...",
  "end_time": "...",
  "duration_sec": ...,
  "stages": {
    "<stage>": {
      "status": "...",
      "error_message": "...",
      "validation": {...}
    }
  },
  "error_message": "..."
}

---

## EXECUTION RULES

- Stop execution on first FAILED stage  
- env.scr always regenerated  
- run.scr must exist  
- No silent failures  

---

# ==============================
# ANALYZER CONTRACT
# ==============================

## INPUT

output/<project>/**/status.json  

---

## OUTPUT

output/<project>/summary/summary.xls  

---

## RESPONSIBILITY

- Read all status.json files  
- Flatten data  
- Aggregate summary  
- Generate Excel report  

---

## SUMMARY FORMAT

Sheet: Summary  

category | total | PASSED | FAILED | NOT_EXECUTED | NOT_PLANNED  

Includes:

- OVERALL row  
- Per-category rows  

---

## CATEGORY SHEETS

category | testcase | status | duration_sec | start_time | end_time | stage_*_status | stage_*_error  

---

## RULES

- Analyzer is READ-ONLY  
- Uses only status.json  
- Dynamic stage handling  
- No inference or modification  

---

# ==============================
# AGENT CONTRACT
# ==============================

## ROLE

Orchestrates execution using:

- planner  
- executor  
- analyzer  

---

## RESPONSIBILITY

- Interpret user intent  
- Trigger correct skill(s)  
- Pass filters to executor  
- Maintain execution order  

---

## SUPPORTED COMMANDS

run planner → Planner  
run executor → Executor  
run analyzer → Analyzer  
run full flow → Planner → Executor → Analyzer  
run <category> → Executor with filter  

---

## EXECUTION RULES

- Full flow must follow strict order  
- Do NOT skip steps  
- Filtering only via executor  

---

## FAILURE HANDLING

- Planner failure → STOP  
- Executor failure → continue to analyzer  
- Analyzer always runs  

---

## OUTPUT EXPECTATION

- Planner → summary  
- Executor → execution logs  
- Analyzer → summary.xls path  

---

## DO NOT

- Do not execute scripts directly  
- Do not read Excel or logs  
- Do not modify filesystem  
- Do not bypass skills  

---

# ==============================
# GLOBAL RULES
# ==============================

- Planner reads Excel  
- Executor reads JSON  
- Analyzer reads status.json  
- Agent does not process data  

---
## STATUS DOMAINS

Planner and Executor use different status domains:

Planner:
- READY
- SKIPPED

Executor:
- PASSED
- FAILED
- NOT_EXECUTED
- NOT_PLANNED
- DISABLED

These MUST NOT be mixed or normalized across components.

---

# ==============================
# DO NOT
# ==============================

- Do not auto-correct inputs  
- Do not infer missing data  
- Do not hide failures  
- Do not mix responsibilities  